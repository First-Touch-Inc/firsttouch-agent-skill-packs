# First-Run Onboarding — RevOps Pack

This onboarding is scoped to the skills and recipes actually included in this installed pack.

## Ask before running anything
1. **LinkedIn account type:** free/basic or Sales Navigator/Premium.
   - Free/basic: no connection notes; 10 connection requests/day max.
   - Sales Navigator/Premium: connection notes available for approved warm signals; up to 20 connection requests/day.
   - AI SDR and all other connection-request plays share the same daily budget.
   - If AI SDR and a social campaign run on the same sender/day, pause/reduce one motion or split the daily cap explicitly before queueing sends.
   - Already-connected first-message rows use a separate, non-FirstTouch-enforced norm of about 30-40 messages/day. Stay well under it and reduce volume if acceptance or reply quality drops.
2. **HubSpot access:** MCP connected by an admin, service key/private app token from an admin, HubSpot list only, or none. Do not ask a rep/BDR to mint credentials they do not own.
3. **ICP/list/source data:** if HubSpot is absent, ask for ICP criteria or an imported/FirstTouch-accessible list before qualifying prospects.
4. **Persona start point:** recommend the persona-specific start point below, not a generic catalog dump.

## Persona start point
Start with **Pre-launch rollout audit** before any rep launches volume. Then govern the core rollout: HubSpot list triggers, AI SDR queue QA, social campaigns, stalled-deal workflows, and **Attribution & team performance review** as the recurring reporting cadence. Keep situational plays such as events, customer thank-you, website visitors, and closed-lost reengagement for after the core governance path is stable.

- Social engagement / warm engager flows are delivered by `warm-engager-followup`. They use LinkedIn post likes and comments from Social Engagement monitoring when enabled in the workspace, or a user-provided/exported engager list. Ask whether Social Engagement is enabled before steering the user to a monitored-profile play. Profile-view capture is not treated as MCP-native.

## Available recipes in this pack
#### Core governance
| Recipe | What it does | Needs |
|---|---|---|
| Pre-launch rollout audit | Run once before first launch or major rollout: MCP connections, approval workflow, suppression checks, sequence quality, logging round-trip, and per-seat safety limits. | No HubSpot required; HubSpot improves CRM/owner checks |
| Attribution & team performance review | Run the recurring RevOps reporting cadence as its own report: pull FirstTouch team metrics for the trailing 30 days by flow, sender, and date, then reconcile sends, replies, sentiment, meetings, and opportunities against HubSpot logging coverage. | No HubSpot required for FirstTouch team metrics; HubSpot improves opportunity/pipeline reconciliation |
| HubSpot list trigger — team-wide LinkedIn flows | Use HubSpot lists or contact-based workflow outputs as the trigger source for FirstTouch LinkedIn outreach across your team. Confirm FirstTouch action cards using references/hubspot-setup.md; if cards are not present, use the documented HubSpot list/source fallback. | HubSpot required |
| Govern and audit AI SDR daily queues | Run on a recurring cadence after launch: review team-wide AI SDR queues through sequence QA plus workspace-audit Step 6 queue/status hygiene, including 10/20 daily caps, approval workflow, blocked/review-required rows, failed actions, and queue hygiene. Do not promise automated aged-queue alerts unless an alerting workflow is configured. | No HubSpot required for QA/audit; HubSpot improves owner routing; queue status depends on FirstTouch outreach/task visibility |
| Social campaigns — team-routed operational campaigns | Build governed campaigns such as inbound-signup decision-maker enrichment, CEO touches to stuck $50k+ deals, or product-update messaging to first-degree team connections at target accounts. RevOps chooses row-level dynamic approvals or a static flow-level campaign based on risk. | No HubSpot required for imported target-account/connection lists; HubSpot required for inbound owner routing, deal amount, deal age, or customer/deal segments |
| Stalled deal reactivation spec — team-wide | Produce the contact-based stalled-deal qualification spec, qualifying HubSpot list/workflow setup steps, and owner-approved LinkedIn reactivation queue. Automation is only claimed after RevOps confirms the portal/source can feed FirstTouch. | HubSpot required; RevOps/admin may be needed only for recurring workflow setup |
#### Situational rollout plays
| Recipe | What it does | Needs |
|---|---|---|
| Social engager setup for team | Configure warm-engager signal capture and flows so the whole team benefits from content engagement; use ICP outbound builder only to enrich or qualify the engager audience before routing, not as a simultaneous send motion. | No HubSpot required; monitor owned leadership or relevant competitor/influencer profiles; HubSpot optional for qualification/routing; ICP outbound builder is for audience enrichment/qualification fallback; profile views unavailable |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active; if no visitor signal source exists, choose the AI SDR recipe as a separate prospecting motion instead. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion |
| Closed-lost reengagement — team-wide | Re-engage historical closed-lost accounts across all reps when RevOps explicitly chooses a win-back motion; keep this separate from stalled open-deal reactivation. | HubSpot required; separate from stalled open-deal workflow |
| HubSpot setup guide for FirstTouch-triggered actions | Coach RevOps/admin through references/hubspot-setup.md: confirm whether FirstTouch action cards exist in HubSpot workflows, or use the supported fallback of a HubSpot list/source that FirstTouch reads before enrolling/queueing actions. | HubSpot required; confirm action cards exist in the customer portal before promising UI steps |
| Event plays — pre-invite and post-follow-up | Build audience and invite flow before an event, then run follow-up flows to attendees and no-shows. | HubSpot or imported attendee/source list required |
| Customer thank-you | Reach out when a customer hits a milestone — deepen the relationship before you need a favor. | HubSpot required |

## Included skills and dependency status
| Skill | Needs |
|---|---|
| `firsttouch-messaging` | No HubSpot required |
| `inbound-speed-to-lead` | HubSpot or FirstTouch-accessible inbound list/import required; true automation needs a connected source |
| `warm-engager-followup` | No HubSpot required; Social Engagement must be enabled in the workspace for monitored profiles; user-provided/exported engager lists also work |
| `website-visitor-followup` | HubSpot tracking or RB2B/list source required |
| `icp-outbound-builder` | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional |
| `hubspot-signal-to-linkedin-touch` | HubSpot required |
| `social-campaigns` | No HubSpot for pure ICP/imported/connection-list campaigns; HubSpot required for CRM/deal/customer segments |
| `stalled-deal-reactivation` | HubSpot required; may need RevOps/admin for workflow setup |
| `customer-champion` | HubSpot required |
| `sequence-qa-reviewer` | No HubSpot for FirstTouch QA; HubSpot improves duplicate/owner checks |
| `workspace-audit` | No HubSpot for FirstTouch-only audit; HubSpot needed for owner/logging coverage |
| `team-performance-report` | No HubSpot required for FirstTouch team metrics; HubSpot improves opportunity/pipeline reconciliation |

## HubSpot access rules for this pack
- If HubSpot is connected, HubSpot-specific recipes can read CRM context, owner, lifecycle/deal/list data, and log back where the connected FirstTouch-HubSpot integration supports it.
- If HubSpot is used but no MCP/key is connected, ask for a HubSpot list or other FirstTouch-accessible source before running HubSpot-dependent motions.
- If HubSpot is not used, run only the recipes above whose Needs column says no HubSpot or imported/Discover/list source is enough.

## Social Engagement source options
Social Engagement can monitor relevant LinkedIn profiles for post likes and comments. Prefer the user's own founder/leadership/company profile when available; if they do not have enough owned engagement yet, monitor a relevant competitor founder, category influencer, or executive profile and work the ICP-fit people engaging there. Profile views are not an available signal.

## Approval model
Publishing a flow activates it but does **not** enroll awaiting contacts. After approval, explicitly enroll the approved contacts/items, then confirm they moved from awaiting to in-progress.

| Motion | Approval style |
|---|---|
| AI SDR / dynamic actions | Row-level approval. Each first-touch row must be approved individually. |
| Warm engager, inbound, website visitor, HubSpot signal, customer/stalled deal | Row-level approval unless FirstTouch records an equivalent per-contact approval. |
| Social campaigns | Two modes: rep/BDR dynamic rows use row-level approval like AI SDR; RevOps/founder one-time static campaigns can use flow-level approval after exact audience, templates, sender/routing rule, launch window, and daily cap are approved. |

## Onboarding output format
```markdown
## FirstTouch onboarding summary
- Persona: revops
- LinkedIn account: Free/basic or Sales Navigator/Premium
- Daily connection cap: 10 or 20 shared across all plays
- Daily message norm: about 30-40/day for already-connected first-message rows, not FirstTouch-enforced; stay well under it
- HubSpot access: MCP / service key / list only / none
- Social Engagement enabled: yes/no/unknown
- ICP/list available if no HubSpot: yes/no + source
- Plays available now from this pack: ...
- Plays blocked until HubSpot access/list or source data exists: ...
- Recommended first play: ...
- Approval workflow: row-level for dynamic plays; flow-level only for approved one-time social campaigns
```
