# Recipe Catalog — RevOps Pack

Use this file when the agent installed `skills/` and `references/` without loading the root README. These recipes are the recommended starting points for the revops persona.

## Recommended start point
Start with **Pre-launch rollout audit** before any rep launches volume. Then govern the core rollout: HubSpot list triggers, AI SDR queue QA, social campaigns, stalled-deal workflows, and **Attribution & team performance review** as the recurring reporting cadence. Keep situational plays such as events, customer thank-you, website visitors, and closed-lost reengagement for after the core governance path is stable.

## Recipes
#### Core governance
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Pre-launch rollout audit | Run once before first launch or major rollout: MCP connections, approval workflow, suppression checks, sequence quality, logging round-trip, and per-seat safety limits. | No HubSpot required; HubSpot improves CRM/owner checks | `workspace-audit` + `sequence-qa-reviewer` |
| Attribution & team performance review | Run the recurring RevOps reporting cadence: pull FirstTouch team metrics for the trailing 30 days by flow, sender, and date, then reconcile sends, replies, sentiment, meetings, and opportunities against HubSpot logging coverage. | No HubSpot required for FirstTouch team metrics; HubSpot improves opportunity/pipeline reconciliation | `workspace-audit` |
| HubSpot list trigger — team-wide LinkedIn flows | Use HubSpot lists or contact-based workflow outputs as the trigger source for FirstTouch LinkedIn outreach across your team. If HubSpot action cards exist in the portal, confirm them first; otherwise produce manual RevOps/admin setup steps. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `inbound-speed-to-lead` |
| Govern and audit AI SDR daily queues | Run on a recurring cadence after launch: review team-wide AI SDR queues, 10/20 daily caps, approval workflow, blocked/review-required rows, failed actions, and queue hygiene. Do not promise automated aged-queue alerts unless an alerting workflow is configured. | No HubSpot required for QA/audit; HubSpot improves owner routing; queue status depends on FirstTouch outreach/task visibility | `sequence-qa-reviewer` + `workspace-audit` |
| Social campaigns — team-routed operational campaigns | Build governed campaigns such as inbound-signup decision-maker enrichment, CEO touches to stuck $50k+ deals, or product-update messaging to first-degree team connections at target accounts. RevOps chooses row-level dynamic approvals or a static flow-level campaign based on risk. | No HubSpot required for imported target-account/connection lists; HubSpot required for inbound owner routing, deal amount, deal age, or customer/deal segments | `social-campaigns` + `firsttouch-messaging` + `workspace-audit` |
| Stalled deal reactivation spec — team-wide | Produce the contact-based stalled-deal qualification spec, qualifying HubSpot list/workflow setup steps, and owner-approved LinkedIn reactivation queue. Automation is only claimed after RevOps confirms the portal/source can feed FirstTouch. | HubSpot required; RevOps/admin may be needed only for recurring workflow setup | `stalled-deal-reactivation` + `firsttouch-messaging` |
#### Situational rollout plays
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social engager setup for team | Configure warm-engager signal capture and flows so the whole team benefits from content engagement; use ICP outbound builder only to enrich or qualify the engager audience before routing, not as a simultaneous send motion. | No HubSpot required; monitor owned leadership or relevant competitor/influencer profiles; HubSpot optional for qualification/routing; ICP outbound builder is for audience enrichment/qualification fallback; profile views unavailable | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active; if no visitor signal source exists, choose the AI SDR recipe as a separate prospecting motion instead. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion | `website-visitor-followup` |
| Closed-lost reengagement — team-wide | Re-engage historical closed-lost accounts across all reps when RevOps explicitly chooses a win-back motion; keep this separate from stalled open-deal reactivation. | HubSpot required; separate from stalled open-deal workflow | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
| HubSpot setup guide for FirstTouch-triggered actions | Coach through confirming whether FirstTouch HubSpot action cards exist; if not, document the supported fallback: a HubSpot list/source that FirstTouch reads, then FirstTouch enrolls or queues actions. | HubSpot required; confirm action cards exist in the customer portal before promising UI steps | `hubspot-signal-to-linkedin-touch` |
| Event plays — pre-invite and post-follow-up | Build audience and invite flow before an event, then run follow-up flows to attendees and no-shows. | HubSpot or imported attendee/source list required | `icp-outbound-builder` + `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Customer thank-you | Reach out when a customer hits a milestone — deepen the relationship before you need a favor. | HubSpot required | `customer-champion` |

## Approval reminder
Dynamic/AI SDR rows require row-level approval. Static social-campaign flows can use flow-level approval only after the exact audience, static templates, sender/routing rule, launch window, and daily cap are approved.
