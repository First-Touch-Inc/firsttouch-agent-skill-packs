# FirstTouch RevOps Pack

> Data chaos and untracked touches make it impossible to prove what's working or govern the team — these are the plays for the job you actually do.

## Who this is for
You own the stack and the data. Every untracked touch is attribution you'll never recover. You care about owner routing, approval workflows, HubSpot data hygiene, and whether this creates compliance risk or solves it. These plays give you the governance layer, the attribution reports, and the team-wide setup plays that turn individual reps' outreach into a measurable, auditable revenue motion.

## First-run onboarding
Before running the first play in this pack, ask the user:

1. **LinkedIn account type:** do they have Sales Navigator / Premium, or a free/basic account?
   - Free/basic: no connection notes; cap connection requests at **10/day**.
   - Sales Navigator / Premium: connection notes available; cap connection requests at **20/day**.
2. **HubSpot access:** do they use HubSpot, and can they connect the HubSpot MCP or provide a HubSpot service key / private app token?
   - If not, run FirstTouch-only plays or ask them to create a HubSpot list/source FirstTouch can access before running HubSpot-specific plays.
3. **Play choice:** show the catalog below and recommend **high-intent plays first**, then outbound once those are running to keep the LinkedIn account healthy.

Use `references/onboarding.md` for the full question flow, account-type rules, and play catalog.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Runs |
|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | `firsttouch-messaging` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent inbound lists. | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed the sender's posts/profile, an executive's posts/profile, or company/leadership content into conversations and pipeline. | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | `website-visitor-followup` |
| icp-outbound-builder | Run the AI SDR motion: start from a HubSpot contact/company list or build a new ICP list via FirstTouch Discover Contacts, enrich each prospect, generate customized LinkedIn-first outreach, and queue a daily batch for human approval. | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | `hubspot-signal-to-linkedin-touch` |
| stalled-deal-reactivation | Build and govern a contact-based HubSpot workflow for contacts associated to open deals that are not Closed Won and not Closed Lost and have had no engagement for 60+ days. | `stalled-deal-reactivation` |
| customer-champion | Reach out to customers when a meaningful milestone is hit — onboarding completed, usage threshold reached, expansion motion started, renewal window opened, or a champion moment appears. | `customer-champion` |
| sequence-qa-reviewer | Review a FirstTouch LinkedIn campaign/sequence for risk and quality before it launches — checking send safety, messaging quality, personalization depth, duplicate risk, and compliance with the FirstTouch messaging framework. | `sequence-qa-reviewer` |
| workspace-audit | Audit a FirstTouch + HubSpot workspace for readiness before launching outreach — checks MCP connections, owner coverage, LinkedIn account health, safety limits, logging setup, and data hygiene. | `workspace-audit` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Needs / HubSpot status | Composes from |
|---|---|---|---|
| Pre-launch rollout audit | Run a team-wide readiness checklist before rollout: MCP connections, approval workflow, suppression checks, sequence quality, and per-seat safety limits. | No HubSpot required; HubSpot improves CRM/owner checks | `workspace-audit` + `sequence-qa-reviewer` |
| HubSpot Workflow trigger — team-wide LinkedIn flows | Use HubSpot lifecycle changes as triggers for LinkedIn outreach flows at scale across your team. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `inbound-speed-to-lead` |
| Social engager setup for team | Configure warm-engager signal capture and flows so the whole team benefits from content engagement. | No HubSpot required; HubSpot optional for qualification/routing | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active. | HubSpot tracking or RB2B/list source required | `website-visitor-followup` + `icp-outbound-builder` |
| Govern and audit AI SDR daily queues | Review, QA, and monitor team-wide AI SDR daily queues before and after launch, including 10/15 daily caps, approval workflow, and aged-queue alerts. | No HubSpot required for QA/audit; HubSpot improves owner routing | `sequence-qa-reviewer` + `workspace-audit` |
| Stalled deal reactivation workflow — team-wide | Trigger a contact-based HubSpot workflow for contacts associated to open deals not Closed Won/Lost with no engagement for 60+ days, then prepare approved reactivation queues by owner. | HubSpot required; contact-based workflow only, because deal-based triggers are unsupported | `stalled-deal-reactivation` + `firsttouch-messaging` |
| Closed-lost reengagement — team-wide | Re-engage historical closed-lost accounts across all reps when RevOps explicitly chooses a win-back motion. | HubSpot required; separate from stalled open-deal workflow | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
| HubSpot Workflow build with FirstTouch actions | Coach through adding FirstTouch action cards/actions such as enroll, view profile, or connect inside HubSpot workflows, when available in the connected portal. | HubSpot required; confirm action cards exist in the customer portal before promising UI steps | `hubspot-signal-to-linkedin-touch` |
| Event plays — pre-invite and post-follow-up | Build audience and invite flow before an event, then run follow-up flows to attendees and no-shows. | HubSpot or imported attendee/source list required | `icp-outbound-builder` + `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Customer thank-you | Reach out when a customer hits a milestone — deepen the relationship before you need a favor. | HubSpot required | `customer-champion` |

### 🔜 Roadmap (not yet shipped)
- CS handoff / retention connector — see `roadmap/cs-handoff-retention.md`
- Customer referral / advocacy ask — see `roadmap/customer-referral-advocacy.md`

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder into your agent:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` (or `.claude/skills/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` folder anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** for FirstTouch execution and approvals. Connect **HubSpot MCP** only for HubSpot-specific plays. See `references/mcp-setup.md`.
4. Complete the first-run onboarding in `references/onboarding.md` before choosing a play.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

## What's NOT included
- **CS handoff / retention connector** — see `roadmap/cs-handoff-retention.md`
- **Customer referral / advocacy ask** — see `roadmap/customer-referral-advocacy.md`
