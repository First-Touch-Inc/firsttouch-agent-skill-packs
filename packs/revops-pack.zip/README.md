# FirstTouch RevOps Pack

> Data chaos and untracked touches make it impossible to prove what's working or govern the team — these are the plays for the job you actually do.

## Who this is for
You own the stack and the data. Every untracked touch is attribution you'll never recover. You care about owner routing, approval workflows, HubSpot data hygiene, and whether this creates compliance risk or solves it. These plays give you the governance layer, the attribution reports, and the team-wide setup plays that turn individual reps' outreach into a measurable, auditable revenue motion.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Runs |
|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | `firsttouch-messaging` |
| owner-safe-outreach-operator | Ensure every LinkedIn outreach action respects owner routing, duplicate checks, account-safety limits, and human approval before it sends — then logs to HubSpot. | `owner-safe-outreach-operator` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent HubSpot events. | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed your LinkedIn posts or profile into conversations and pipeline. | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | `website-visitor-followup` |
| icp-outbound-builder | Build an ICP outbound motion from a HubSpot list or a FirstTouch target-account set: qualify accounts, identify the right personas, enrich/match contacts, and add them into an approved FirstTouch flow. | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | `hubspot-signal-to-linkedin-touch` |
| customer-champion | Reach out to customers when a meaningful milestone is hit — onboarding completed, usage threshold reached, expansion motion started, renewal window opened, or a champion moment appears. | `customer-champion` |
| sequence-qa-reviewer | Review a FirstTouch LinkedIn campaign/sequence for risk and quality before it launches — checking send safety, messaging quality, personalization depth, duplicate risk, and compliance with the FirstTouch messaging framework. | `sequence-qa-reviewer` |
| pipeline-attribution-analyst | Measure and report which LinkedIn/social touches influenced HubSpot pipeline — meetings booked, deals created, revenue touched — by joining FirstTouch activity data with HubSpot deal/contact records. | `pipeline-attribution-analyst` |
| workspace-audit | Audit a FirstTouch + HubSpot workspace for readiness before launching outreach — checks MCP connections, owner coverage, LinkedIn account health, safety limits, logging setup, and data hygiene. | `workspace-audit` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Composes from |
|---|---|---|
| HubSpot Workflow trigger — team-wide LinkedIn flows | Use HubSpot lifecycle changes as triggers for LinkedIn outreach flows at scale across your team | `hubspot-signal-to-linkedin-touch` + `inbound-speed-to-lead` + `owner-safe-outreach-operator` |
| Social engager setup for team | Configure warm-engager signal capture and flows so the whole team benefits from content engagement | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active | `website-visitor-followup` + `icp-outbound-builder` |
| Govern and audit AI SDR builds | Review, QA, and monitor all team-wide LinkedIn outbound before and after launch | `sequence-qa-reviewer` + `workspace-audit` + `owner-safe-outreach-operator` |
| Team-wide slipped lead recovery | Identify dormant pipeline across all reps and reactivate systematically | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `pipeline-attribution-analyst` |
| Closed-lost reengagement — team-wide | Re-engage closed-lost deals with no engagement for 60+ days across all reps | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
| HubSpot Workflow build with FirstTouch actions | Coach through adding FT action cards (Enroll / View Profile / Connect) in HubSpot Automation UI | `hubspot-signal-to-linkedin-touch` |
| Event plays — pre-invite and post-follow-up | Build audience and invite flow before an event, then run follow-up flows to attendees and no-shows | `icp-outbound-builder` + `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Customer thank-you | Reach out when a customer hits a milestone — deepen the relationship before you need a favor | `customer-champion` |

### 🔜 Roadmap (not yet shipped)
- CS handoff / retention connector — see `roadmap/cs-handoff-retention.md`
- Customer referral / advocacy ask — see `roadmap/customer-referral-advocacy.md`

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder into your agent:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` (or `.claude/skills/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` folder anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** + **HubSpot MCP** for most plays. See `references/mcp-setup.md`.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

## What's NOT included
- **CS handoff / retention connector** — see `roadmap/cs-handoff-retention.md`
- **Customer referral / advocacy ask** — see `roadmap/customer-referral-advocacy.md`
