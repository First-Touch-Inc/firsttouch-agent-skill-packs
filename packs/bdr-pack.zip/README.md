# FirstTouch BDR Pack

> Inbox busywork and slow follow-up make you miss the inbound window and look bad to your AE — these are the plays for the job you actually do.

## Who this is for
Your job is meetings. You live in the gap between marketing handing over a lead and sales getting a discovery call on the calendar. Every delay in follow-up, every manual step, every no-show not chased — that's a meeting you didn't book. These plays close that gap: fast inbound response, warm-signal conversion, and lead recovery without the grind.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Runs |
|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | `firsttouch-messaging` |
| owner-safe-outreach-operator | Ensure every LinkedIn outreach action respects owner routing, duplicate checks, account-safety limits, and human approval before it sends — then logs to HubSpot. | `owner-safe-outreach-operator` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent HubSpot events. | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed your LinkedIn posts or profile into conversations and pipeline. | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | `website-visitor-followup` |
| icp-outbound-builder | Build an ICP outbound motion from a HubSpot list or a FirstTouch target-account set: qualify accounts, identify the right personas, enrich/match contacts, and add them into an approved FirstTouch flow. | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | `hubspot-signal-to-linkedin-touch` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Composes from |
|---|---|---|
| Auto-connect on meeting or signup | First LinkedIn touch goes out same day, no manual step — beat the inbound window | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Social engager flow — leadership posts | Convert company content engagement into booked meetings before interest fades | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active | `website-visitor-followup` + `icp-outbound-builder` |
| BDR AI SDR — target list and pacing | Work a target account list with accounts-per-day pacing and LinkedIn-first sequences | `icp-outbound-builder` + `owner-safe-outreach-operator` + `firsttouch-messaging` |
| Scoop-up slipped leads — no-shows and old MQLs | Reach back on no-shows and leads that never converted to opportunities | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |

### 🔜 Roadmap (not yet shipped)
- Rep-led AI SDR — see `roadmap/rep-led-ai-sdr.md`

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder into your agent:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` (or `.claude/skills/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` folder anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** + **HubSpot MCP** for most plays. See `references/mcp-setup.md`.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

## What's NOT included
- **Rep-led AI SDR** — see `roadmap/rep-led-ai-sdr.md`
