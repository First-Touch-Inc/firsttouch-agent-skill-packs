# FirstTouch BDR Pack

> Inbox busywork and slow follow-up make you miss the inbound window and look bad to your AE — these are the plays for the job you actually do.

## Who this is for
Your job is meetings. You live in the gap between marketing handing over a lead and sales getting a discovery call on the calendar. Every delay in follow-up, every manual step, every no-show not chased — that's a meeting you didn't book. These plays close that gap: fast inbound response, warm-signal conversion, and lead recovery without the grind.

## First-run onboarding
Before running the first play in this pack, ask the user:

1. **LinkedIn account type:** do they have Sales Navigator / Premium, or a free/basic account?
   - Free/basic: no connection notes; cap connection requests at **10/day**.
   - Sales Navigator / Premium: connection notes available; cap connection requests at **20/day**.
   - For AI SDR daily queues specifically, use **10/day** on free/basic or **20/day** on Sales Navigator / Premium.
2. **HubSpot access:** do they use HubSpot, and can they connect the HubSpot MCP or provide a HubSpot service key / private app token?
   - If not, run FirstTouch-only plays or ask them to create a HubSpot list/source FirstTouch can access before running HubSpot-specific plays.
3. **Play choice:** show the catalog below and recommend **high-intent plays first**, then outbound once those are running to keep the LinkedIn account healthy.

Use `references/onboarding.md` for the full question flow, account-type rules, and play catalog.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Needs / HubSpot status | Runs |
|---|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | See skill requirements | `firsttouch-messaging` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent inbound lists. | No HubSpot required unless recipe says so | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed the sender's posts/profile, an executive's posts/profile, or company/leadership content into conversations and pipeline. | No HubSpot required unless recipe says so | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | No HubSpot required unless recipe says so | `website-visitor-followup` |
| icp-outbound-builder | Run the AI SDR motion: start from a HubSpot contact/company list or build a new ICP list via FirstTouch Discover Contacts, enrich each prospect, generate customized LinkedIn-first outreach, and queue a daily batch for human approval. | No HubSpot required unless recipe says so | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | HubSpot required | `hubspot-signal-to-linkedin-touch` |
| social-campaigns | Build a one-time LinkedIn social campaign for a very narrow ICP segment: define precise audience criteria, source/enrich contacts from FirstTouch and optional HubSpot lists, build static flow messaging templates, get bulk approval for the flow/campaign, then launch through FirstTouch. | No HubSpot required unless recipe says so | `social-campaigns` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Needs / HubSpot status | Composes from |
|---|---|---|---|
| Auto-connect on meeting or signup | Same-day LinkedIn draft ready for one-click approval, so the BDR beats the inbound window without autonomous sending. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Social engager flow — leadership posts | Convert engagement on CEO/exec/leadership posts into booked meetings before interest fades. | No HubSpot required; HubSpot optional for qualification/routing | `warm-engager-followup` + `firsttouch-messaging` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active; if no visitor signal source exists, fall back to the BDR AI SDR recipe instead of running both on the same contacts. | HubSpot tracking or RB2B/list source required; otherwise route to BDR AI SDR | `website-visitor-followup` + `icp-outbound-builder` |
| BDR AI SDR — daily approval queue | View a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 20/day Sales Nav/Premium meeting-generation touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `icp-outbound-builder` + `firsttouch-messaging` |
| Social campaigns — narrow ICP meeting push | Build a one-time LinkedIn campaign for a narrow BDR segment such as connected leadership titles, last-year no-shows, or ICP buyers in a tradeshow city, using approved static templates and flow-level approval. | No HubSpot required for Discover Contacts or connection/list sources; HubSpot required for no-show or CRM-history segments | `social-campaigns` + `firsttouch-messaging` |
| Scoop-up slipped leads — no-shows and old MQLs | Reach back on no-shows and leads that never converted to opportunities. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder **and the shared `references/` folder** into your agent. Skills use `../../references/...`, so references must sit two levels above each `SKILL.md`:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` and copy `references/` to `~/.claude/references/` (or use `.claude/skills/` plus `.claude/references/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` and `references/` folders anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** for FirstTouch execution and approvals. Connect **HubSpot MCP** only for HubSpot-specific plays. See `references/mcp-setup.md`.
4. Complete the first-run onboarding in `references/onboarding.md` before choosing a play.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

