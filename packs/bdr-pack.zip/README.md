# FirstTouch BDR Pack

> Inbox busywork and slow follow-up make you miss the inbound window and look bad to your AE — these are the plays for the job you actually do.

## Who this is for
Your job is meetings. You live in the gap between marketing handing over a lead and sales getting a discovery call on the calendar. Every delay in follow-up, every manual step, every no-show not chased — that's a meeting you didn't book. These plays close that gap: fast inbound response, warm-signal conversion, and lead recovery without the grind.

## Start here
Use this source-based chooser:

| What you have today | Run first | Why |
|---|---|---|
| No source/list yet | **BDR AI SDR** | Daily meeting engine from ICP + Discover Contacts |
| No-show, event, old-MQL, or HubSpot list | **Scoop-up slipped leads** | Lead recovery from a provided source |
| Connected inbound feed or imported signup/demo list | **Auto-connect on meeting or signup** | Same-day inbound follow-up |
| RB2B/HubSpot visitor source | **Website visitor play** | Conditional; most BDRs skip if no visitor source exists |

Then add **Social engager flow** for leadership/competitor/influencer post engagement. Use **Social campaigns** only for manager-approved special pushes, not normal daily work.

## How to use this pack
- **Recipes** are the best starting point. They combine the right skills into the job you actually want done.
- **Skills** are the individual building blocks. Run a skill directly only when you know the exact motion you want.
- **Read once:** `references/system-grounding.md` explains how agents, FirstTouch, HubSpot, approvals, and measurement fit together.
- **FirstTouch terms:** a campaign/sequence/social campaign in this pack becomes a FirstTouch audience, flow plan, dynamic action, or enrollment depending on the play. "AI SDR" in this pack maps to `icp-outbound-builder`. The agent should use FirstTouch's available execution objects and state the exact object it created.
- **Approval locations:** approvals can happen in-agent, in FirstTouch, Slack, or email depending on your workspace. If the approval location is not configured, the agent must present the table in chat and wait.

## First-run onboarding
Before running the first play in this pack, ask the user:

1. **LinkedIn account type:** do they have Sales Navigator / Premium, or a free/basic account?
   - Free/basic: no connection notes; cap connection requests at **10/day**.
   - Sales Navigator / Premium: connection notes available; cap connection requests at **20/day**.
   - AI SDR shares the same daily connection-request budget. If AI SDR and another play run on the same day, the total across all plays must stay within 10 or 20.
2. **HubSpot access:** do they use HubSpot, and can an admin connect the HubSpot MCP, provide a service key / private app token, or at least provide a HubSpot list FirstTouch can access?
   - If not, use the FirstTouch-only paths below or ask them to create a HubSpot list/source FirstTouch can access before running HubSpot-specific plays.
3. **Play choice:** show the catalog below and recommend the persona-specific start-here play above.

Use `references/onboarding.md` for the full question flow and account-type rules. Use `references/recipes.md` for the generated recipe catalog if the README is not loaded by the agent.

## HubSpot reality check
- **What works without HubSpot:** BDR AI SDR from FirstTouch Discover Contacts, social engager flow from leadership/competitor/influencer profiles, and special social campaigns from imported/Discover lists. Inbound speed-to-lead needs HubSpot or a FirstTouch-accessible inbound source.
- **What needs HubSpot:** CRM lifecycle/deal criteria, owner routing, HubSpot timeline logging, stalled-deal workflows, and contact/company lists stored only in HubSpot. Without HubSpot/list access, use the FirstTouch-only recipes and do not promise existing-pipeline/deal recovery.
- **FirstTouch-accessible list/import means:** a CSV, static list, audience, or HubSpot list that FirstTouch can read. For true inbound automation, connect HubSpot or another source that continuously feeds FirstTouch.
- **Enrichment is optional but useful:** FirstTouch can enrich contacts/companies when credits and data are available. Clay/Surfe or another enrichment MCP is an optional supplement, not a prerequisite. Without a usable LinkedIn URL or enough verified data, the agent should skip or queue incomplete records rather than fabricate.

## Your plays

### Skills catalog (check Needs before running)
| Skill | What it does | Needs / access status | Runs |
|---|---|---|---|
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent inbound lists. | HubSpot or FirstTouch-accessible inbound list/import required; true automation needs a connected source | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked or commented on the sender's posts, an executive's posts, company/leadership content, or a relevant competitor founder/influencer profile into conversations and pipeline. | No HubSpot required; Social Engagement must be enabled in the workspace for monitored profiles; user-provided/exported engager lists also work | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | HubSpot tracking or RB2B/list source required | `website-visitor-followup` |
| icp-outbound-builder | Run the AI SDR motion: start from a HubSpot contact/company list or build a new ICP list via FirstTouch Discover Contacts, enrich each prospect, generate customized LinkedIn-first outreach, and queue a daily batch for human approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | HubSpot required | `hubspot-signal-to-linkedin-touch` |
| social-campaigns | Build a focused LinkedIn social campaign for a very narrow ICP segment: define precise audience criteria, source/enrich contacts from FirstTouch and optional HubSpot lists, then choose either row-level dynamic actions for rep/BDR one-at-a-time execution or static flow templates for RevOps/founder-approved one-time campaigns. | No HubSpot for pure ICP/imported/connection-list campaigns; HubSpot required for CRM/deal/customer segments | `social-campaigns` |

### 🧩 Support skills (called by plays)
| Skill | What it does | Needs / HubSpot status | Runs |
|---|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | No HubSpot required | `firsttouch-messaging` |

### Recipes (recommended starting points)
#### Inbound / source-gated plays
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Auto-connect on meeting or signup | Inbound only: when a meeting/signup source is already connected or imported, prepare same-day LinkedIn drafts for approval. If no inbound source exists, use BDR AI SDR instead. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Conditional, most BDRs skip unless RB2B/HubSpot tracking or a visitor list exists: turn pricing/demo/product-page visits into LinkedIn touches while intent is active. | Conditional; HubSpot tracking, RB2B/list source, or visitor export required; most BDRs skip if no source exists | `website-visitor-followup` |
#### Daily engine
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| BDR AI SDR — daily approval queue | Daily engine: discover or load ICP-fit prospects, enrich each prospect, and draft connection-request rows up to the 10/day free or 20/day Sales Nav/Premium connection-request cap for approval. Already-connected message rows use the separate message cap. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `icp-outbound-builder` + `firsttouch-messaging` |
#### Warm social signals
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social engager flow — leadership posts | Convert engagement on CEO/exec/leadership posts into booked meetings before interest fades. | No HubSpot required; use leadership, competitor founder, or influencer profile engagement; HubSpot optional for qualification/routing; profile views unavailable | `warm-engager-followup` + `firsttouch-messaging` |
#### Manager-approved special pushes
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social campaigns — special row-level push | Build a manager-approved narrow BDR push such as tradeshow-city buyers, no-shows from a provided event/HubSpot list, or connected leadership titles. Default to AI-SDR-like row-level dynamic approvals, not self-serve flow building. | No HubSpot required for Discover Contacts or imported/event lists; HubSpot required for no-show or CRM-history segments; row-level approval by default; manager/RevOps approval recommended | `social-campaigns` + `firsttouch-messaging` |
#### Lead recovery
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Scoop-up slipped leads — no-shows and old MQLs | Lead recovery: work no-shows and old MQLs from a HubSpot/event list, RevOps-supplied property, or imported source. If no recovery source exists, use BDR AI SDR instead. | HubSpot/event list, RevOps-supplied property, or imported source required | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |

## Install
1. Download this pack zip and extract it so `skills/` and `references/` sit side by side.
2. Install for your agent:
   - **Claude Code:** copy `skills/<skill-name>/` folders to `~/.claude/skills/` and copy `references/` to `~/.claude/references/`. The generated recipe catalog lives in `references/recipes.md` and the full onboarding/play chooser lives in `references/onboarding.md`, so recipes survive non-zip installs. From `~/.claude/skills/<skill-name>/SKILL.md`, `../../references/` resolves to `~/.claude/references/`.
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. If only one skill registers, unzip locally and upload each `<skill>/` folder zip individually.
   - **Cursor / Windsurf:** copy this pack into the project or workspace location your agent reads for skills; keep `skills/` and `references/` together at the same root.
   - **ChatGPT:** connect `https://mcp.firsttouch.ai` as an MCP connector. ChatGPT does not consume the skills folder directly; use the README/skill text as operating prompts if needed.
3. Connect **FirstTouch MCP**. Connect **HubSpot MCP** only for HubSpot-specific plays. See `references/mcp-setup.md`.
4. Complete first-run onboarding before choosing a play.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Dynamic outbound and AI SDR require row-level approval. Social campaigns support two modes: rep/BDR one-at-a-time dynamic rows use row-level approval; one-time static campaign flows can use flow-level approval only after the exact audience, templates, sender routing, launch window, and daily cap are approved.
- Publishing a flow activates it but does **not** enroll awaiting contacts. After approval, explicitly enroll the approved contacts/items, then confirm they moved from awaiting to in-progress.
- Built around LinkedIn's real limits: 10/day free/basic, 20/day Sales Navigator/Premium. When possible, inspect current queue/usage before adding more connection-request rows, rather than relying on estimates.
- See `references/safety-governance.md`.
