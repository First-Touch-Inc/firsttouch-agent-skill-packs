# Recipe Catalog — BDR Pack

Use this file when the agent installed `skills/` and `references/` without loading the root README. These recipes are the recommended starting points for the bdr persona.

## Recommended start point
**Daily engine:** start with **BDR AI SDR** from ICP + Discover Contacts when no inbound feed is wired. **Lead recovery:** run **Scoop-up slipped leads** for no-shows and old MQLs only when you have a HubSpot/event list, RevOps-supplied property, or imported source. **Inbound:** use **Auto-connect on meeting or signup** only when a HubSpot or FirstTouch-accessible inbound source already exists. **Conditional:** use **Website visitor play** only if RB2B/HubSpot tracking or a visitor list exists; most BDRs skip it. Add **Social engager flow** for leadership/competitor/influencer post engagement, and reserve **Social campaigns** for manager-approved special pushes.

## Recipes
#### Inbound / source-gated plays
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Auto-connect on meeting or signup | Inbound only: when a meeting/signup source is already connected or imported, prepare same-day LinkedIn drafts for approval. If no inbound source exists, use BDR AI SDR instead. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Conditional, most BDRs skip unless RB2B/HubSpot tracking or a visitor list exists: turn pricing/demo/product-page visits into LinkedIn touches while intent is active. | Conditional; HubSpot tracking, RB2B/list source, or visitor export required; most BDRs skip if no source exists | `website-visitor-followup` |
#### Daily engine
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| BDR AI SDR — daily approval queue | Daily engine: discover or load ICP-fit prospects, enrich each prospect, and draft connection-request rows up to the 10/day free or 20/day Sales Nav/Premium connection-request cap for approval. Already-connected message rows use the separate message cap. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `icp-outbound-builder` + `firsttouch-messaging` |
#### Warm social signals
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social engager flow — leadership posts | Convert engagement on CEO/exec/leadership posts into booked meetings before interest fades. | No HubSpot required; use leadership, competitor founder, or influencer profile engagement; HubSpot optional for qualification/routing; profile views unavailable | `warm-engager-followup` + `firsttouch-messaging` |
#### Manager-approved special pushes
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social campaigns — special row-level push | Build a manager-approved narrow BDR push such as tradeshow-city buyers, no-shows from a provided event/HubSpot list, or connected leadership titles. Default to AI-SDR-like row-level dynamic approvals, not self-serve flow building. | No HubSpot required for Discover Contacts or imported/event lists; HubSpot required for no-show or CRM-history segments; row-level approval by default; manager/RevOps approval recommended | `social-campaigns` + `firsttouch-messaging` |
#### Lead recovery
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Scoop-up slipped leads — no-shows and old MQLs | Lead recovery: work no-shows and old MQLs from a HubSpot/event list, RevOps-supplied property, or imported source. If no recovery source exists, use BDR AI SDR instead. | HubSpot/event list, RevOps-supplied property, or imported source required | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |

## Approval reminder
Dynamic/AI SDR rows require row-level approval. Static social-campaign flows can use flow-level approval only after the exact audience, static templates, sender/routing rule, launch window, and daily cap are approved.
