# Recipe Catalog — BDR Pack

Use this file when the agent installed `skills/` and `references/` without loading the root README. These recipes are the recommended starting points for the bdr persona.

## Recommended start point
If there is no already-configured inbound feed, start with **BDR AI SDR** as the daily engine from ICP + Discover Contacts. To work no-shows and old MQLs, run **Scoop-up slipped leads** when you have a HubSpot/event list, RevOps-supplied property, or imported source. Use **Auto-connect on meeting or signup** only when a HubSpot or FirstTouch-accessible inbound source is already available; it runs when the agent is run or scheduled unless a connected source continuously feeds it. Add **Social engager flow** from leadership, competitor founder, or influencer profiles when Social Engagement is enabled in the workspace or an exported engager list is available. Use **Social campaigns** for special manager-approved pushes, usually as row-level dynamic actions rather than a self-serve flow-building exercise.

## Recipes
#### Requires inbound, HubSpot, or external source
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Auto-connect on meeting or signup | When an inbound source is already connected or imported, prepare same-day LinkedIn drafts for one-click approval; this runs when the agent runs or on a schedule unless a source continuously feeds FirstTouch. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active; if no visitor signal source exists, choose the BDR AI SDR recipe as a separate prospecting motion instead. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion | `website-visitor-followup` |
| Scoop-up slipped leads — no-shows and old MQLs | Work no-shows and old MQLs from a HubSpot/event list, RevOps-supplied property, or imported source; if no source exists, use BDR AI SDR instead. | HubSpot/event list, RevOps-supplied property, or imported source required | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
#### Daily engine and manager-approved pushes
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| BDR AI SDR — daily approval queue | View a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 20/day Sales Nav/Premium meeting-generation touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `icp-outbound-builder` + `firsttouch-messaging` |
| Social engager flow — leadership posts | Convert engagement on CEO/exec/leadership posts into booked meetings before interest fades. | No HubSpot required; use leadership, competitor founder, or influencer profile engagement; HubSpot optional for qualification/routing; profile views unavailable | `warm-engager-followup` + `firsttouch-messaging` |
| Social campaigns — special row-level push | Build a manager-approved narrow BDR push such as tradeshow-city buyers, no-shows from a provided event/HubSpot list, or connected leadership titles. Default to AI-SDR-like row-level dynamic approvals, not self-serve flow building. | No HubSpot required for Discover Contacts or imported/event lists; HubSpot required for no-show or CRM-history segments; row-level approval by default; manager/RevOps approval recommended | `social-campaigns` + `firsttouch-messaging` |

## Approval reminder
Dynamic/AI SDR rows require row-level approval. Static social-campaign flows can use flow-level approval only after the exact audience, static templates, sender/routing rule, launch window, and daily cap are approved.
