---
name: icp-outbound-builder
description: Build an ICP outbound motion from a HubSpot list or a FirstTouch target-account set: qualify accounts, identify the right personas, enrich/match contacts, and add them into an approved FirstTouch flow. Use when the user wants to run outbound against a target account list, build a clean LinkedIn prospecting list, qualify ICP accounts, or operationalize outbound from HubSpot.
metadata:
  author: firsttouch
  version: "1.0"
  category: play
  requires: [firsttouch-mcp, hubspot-mcp]
---

# Play 14 — ICP Outbound Builder

**Outcome:** Take a list of target accounts, qualify them, identify the right personas, and prepare them for safe FirstTouch outreach.

## When to use
- "Run outbound against this HubSpot list"
- "Build a LinkedIn outbound motion for these target accounts"
- "Find the right personas and add them to flow"
- account-based outbound planning

## Inputs
- **source list:** HubSpot list, target-account set, or CSV imported into FirstTouch
- **ICP criteria:** industry, size, geography, tech stack, role, seniority
- **persona targets:** champion / manager / VP / founder

## Step-by-step

### 1. Pull the source set
Read the target account/contact list from HubSpot or FirstTouch.

### 2. Qualify the accounts
For each account, score against ICP:
- firmographic fit
- technographic fit
- geography
- signal strength (hiring, growth, intent, active outbound team)

Split into:
- **Tier 1** strategic
- **Tier 2** good fit
- **Tier 3** low-context / volume
- **Exclude** poor fit

### 3. Identify the right personas
For each qualified account, find the contact set needed for the motion:
- practitioner / champion
- manager / operator
- decision maker / economic buyer

Use HubSpot first, then enrichment if needed.

### 4. Check contact readiness
Per contact:
- owner assigned?
- LinkedIn URL available?
- already contacted / in active sequence?
- connected status?

### 5. Recommend the flow
Do **not** send yet. Recommend the appropriate motion:
- warm engager follow-up
- signal-triggered touch
- founder-led outbound
- standard outbound connection request + follow-up

### 6. Draft the first touch if requested
If the user wants ready-to-send drafts, load `firsttouch-messaging` and draft per contact tier. Keep it light and smallest-ask-first.

### 7. Add to approved flow
Once approved, add the contacts to the appropriate FirstTouch flow/campaign and route execution through `owner-safe-outreach-operator`.

## Output
- qualified account/contact table
- tiering + persona map
- recommended motion per segment
- optional first-touch drafts
- ready-to-activate outbound queue

## Pitfalls
- over-personalizing low-tier accounts
- skipping owner assignment and duplicate checks before adding to flow
- treating every account like a founder-led account
- qualifying too loosely and letting junk into the sequence

## Reference
- Messaging: [`../../references/messaging-framework.md`](../../references/messaging-framework.md)
- Safety/execution: load `owner-safe-outreach-operator`
- Mapping: load `champion-mapper` when only the account is known
