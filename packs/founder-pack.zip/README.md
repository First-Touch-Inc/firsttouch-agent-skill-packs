# FirstTouch Founder Pack

> Looking automated or spammy on LinkedIn risks the reputation you spent years building — these are the plays for the job you actually do.

## Who this is for
You do your own sales. Your name is your brand, and every automated-feeling LinkedIn message risks undoing years of relationship-building. You need outreach that sounds exactly like you — in the signals you'd actually notice, at the volume that feels personal, not like a drip campaign. These plays are designed for founders who want LinkedIn to feel like them, not like an SDR they hired.

## First-run onboarding
Before running the first play in this pack, ask the user:

1. **LinkedIn account type:** do they have Sales Navigator / Premium, or a free/basic account?
   - Free/basic: no connection notes; cap connection requests at **10/day**.
   - Sales Navigator / Premium: connection notes available; cap connection requests at **20/day**.
   - For AI SDR daily queues specifically, use the stricter cap: **10/day** on free/basic or **15/day** on Sales Navigator / Premium.
2. **HubSpot access:** do they use HubSpot, and can they connect the HubSpot MCP or provide a HubSpot service key / private app token?
   - If not, run FirstTouch-only plays or ask them to create a HubSpot list/source FirstTouch can access before running HubSpot-specific plays.
3. **Play choice:** show the catalog below and recommend **high-intent plays first**, then outbound once those are running to keep the LinkedIn account healthy.
   - For founders, recommend **Social engagement flow** first. It does not require HubSpot.

Use `references/onboarding.md` for the full question flow, account-type rules, and play catalog.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Needs / HubSpot status | Runs |
|---|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | See skill requirements | `firsttouch-messaging` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent inbound lists. | No HubSpot required unless recipe says so | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed the sender's posts/profile, an executive's posts/profile, or company/leadership content into conversations and pipeline. | No HubSpot required unless recipe says so | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | No HubSpot required unless recipe says so | `website-visitor-followup` |
| founder-led-outbound | Run the founder AI SDR motion: build a targeted prospect list from a HubSpot list or FirstTouch Discover Contacts, enrich each prospect, draft founder-voice LinkedIn outreach, and queue a small daily batch for founder approval. | No HubSpot required unless recipe says so | `founder-led-outbound` |
| customer-champion | Reach out to customers when a meaningful milestone is hit — onboarding completed, usage threshold reached, expansion motion started, renewal window opened, or a champion moment appears. | HubSpot required | `customer-champion` |
| stalled-deal-reactivation | Build and govern a contact-based HubSpot workflow for contacts associated to open deals that are not Closed Won and not Closed Lost and have had no engagement for 60+ days. | HubSpot required | `stalled-deal-reactivation` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | HubSpot required | `hubspot-signal-to-linkedin-touch` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Needs / HubSpot status | Composes from |
|---|---|---|---|
| Social engagement flow — founder posts | Start with the warmest founder motion: ICP-qualify people engaging with your posts, check connection status, and draft a light founder-voice touch for approval. No HubSpot required. | No HubSpot required; HubSpot optional for CRM context | `warm-engager-followup` + `firsttouch-messaging` |
| Founder-led AI SDR — daily approval queue | Use a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 15/day Sales Nav/Premium founder-voice touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `founder-led-outbound` |
| Fast personal inbound follow-up | Connect with high-intent signups and demo requests on LinkedIn same day, in your voice. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active. | HubSpot tracking or RB2B/list source required; otherwise route to Founder AI SDR | `website-visitor-followup` + `firsttouch-messaging` |
| Scoop-up slipped leads | Use HubSpot lifecycle/deal/list data to find personal lost deals and dormant contacts worth a second look. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Stalled deal reactivation — 60-day open-deal workflow | Trigger a contact-based HubSpot workflow when contacts are associated to open deals that are not Closed Won/Lost and have had no engagement for 60+ days, then draft a fresh founder-voice LinkedIn touch for approval. | HubSpot required; contact-based workflow only, because deal-based triggers are unsupported | `stalled-deal-reactivation` + `firsttouch-messaging` |
| Customer thank-you | Reach out when a customer hits a milestone, deepen the relationship before you need a favor. | HubSpot required | `customer-champion` |

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder **and the shared `references/` folder** into your agent. Skills use `../../references/...`, so references must sit two levels above each `SKILL.md`:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` and copy `references/` to `~/.claude/references/` (or use `.claude/skills/` plus `.claude/references/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` and `references/` folders anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** for FirstTouch execution and approvals. Connect **HubSpot MCP** only for HubSpot-specific plays. See `references/mcp-setup.md`.
4. Complete the first-run onboarding in `references/onboarding.md` before choosing a play.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

