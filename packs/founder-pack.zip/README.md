# FirstTouch Founder Pack

> Looking automated or spammy on LinkedIn risks the reputation you spent years building — these are the plays for the job you actually do.

## Who this is for
You do your own sales. Your name is your brand, and every automated-feeling LinkedIn message risks undoing years of relationship-building. You need outreach that sounds exactly like you — in the signals you'd actually notice, at the volume that feels personal, not like a drip campaign. These plays are designed for founders who want LinkedIn to feel like them, not like an SDR they hired.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Runs |
|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | `firsttouch-messaging` |
| owner-safe-outreach-operator | Ensure every LinkedIn outreach action respects owner routing, duplicate checks, account-safety limits, and human approval before it sends — then logs to HubSpot. | `owner-safe-outreach-operator` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent HubSpot events. | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed your LinkedIn posts or profile into conversations and pipeline. | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | `website-visitor-followup` |
| icp-outbound-builder | Build an ICP outbound motion from a HubSpot list or a FirstTouch target-account set: qualify accounts, identify the right personas, enrich/match contacts, and add them into an approved FirstTouch flow. | `icp-outbound-builder` |
| founder-led-outbound | Run founder-style LinkedIn outbound — high-personalization, signal-led outreach from a founder or executive persona to strategic accounts, with social proof and owner-safe gating. | `founder-led-outbound` |
| customer-champion | Reach out to customers when a meaningful milestone is hit — onboarding completed, usage threshold reached, expansion motion started, renewal window opened, or a champion moment appears. | `customer-champion` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | `hubspot-signal-to-linkedin-touch` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Composes from |
|---|---|---|
| Fast personal inbound follow-up | Connect with high-intent signups and demo requests on LinkedIn same day, in your voice | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Social engager flow — my posts | ICP-qualify people reacting to your own posts and start conversations while intent is hot | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active | `website-visitor-followup` + `icp-outbound-builder` |
| Founder-led AI SDR | Run founder-voice strategic outbound to Tier-1 accounts without it eating your week | `icp-outbound-builder` + `founder-led-outbound` + `owner-safe-outreach-operator` |
| Scoop-up slipped leads | HubSpot query for personal lost deals and dormant contacts worth a second look | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
| Connection mining | Search your own LinkedIn connections by ICP criteria, qualify them, and add to a campaign | `icp-outbound-builder` + `owner-safe-outreach-operator` |
| Closed-lost reengagement | Re-engage closed-lost deals with no engagement for 60+ days via a fresh LinkedIn touch | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |
| Customer thank-you | Reach out when a customer hits a milestone — deepen the relationship before you need a favor | `customer-champion` |

### 🔜 Roadmap (not yet shipped)
- Customer referral / advocacy ask — see `roadmap/customer-referral-advocacy.md`

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder into your agent:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` (or `.claude/skills/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` folder anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** + **HubSpot MCP** for most plays. See `references/mcp-setup.md`.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

## What's NOT included
- **Customer referral / advocacy ask** — see `roadmap/customer-referral-advocacy.md`
