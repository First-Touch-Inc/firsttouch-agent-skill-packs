# First-Run Onboarding — Founder Pack

This onboarding is scoped to the skills and recipes actually included in this installed pack.

## Ask before running anything
1. **LinkedIn account type:** free/basic or Sales Navigator/Premium.
   - Free/basic: no connection notes; 10 connection requests/day max.
   - Sales Navigator/Premium: connection notes available for approved warm signals; up to 20 connection requests/day.
   - AI SDR and all other connection-request plays share the same daily budget.
   - If AI SDR and a social campaign run on the same sender/day, pause/reduce one motion or split the daily cap explicitly before queueing sends.
2. **HubSpot access:** MCP connected by an admin, service key/private app token from an admin, HubSpot list only, or none. Do not ask a rep/BDR to mint credentials they do not own.
3. **ICP/list/source data:** if HubSpot is absent, ask for ICP criteria or an imported/FirstTouch-accessible list before qualifying prospects.
4. **Persona start point:** **Start here:**
1. **No HubSpot + Social Engagement enabled:** run **Social engagement flow — founder posts** first. Confirm in FirstTouch Social / workspace settings before starting.
2. **No HubSpot + thin/no engagement:** monitor a relevant competitor founder or category influencer, use an exported engager list, or go straight to **Founder-led AI SDR** from Discover Contacts.
3. **Have HubSpot:** add inbound, visitor, and stalled-deal plays as secondary CRM/deal motions, not the default path.

- Social engagement / warm engager flows are delivered by `warm-engager-followup`. They use LinkedIn post likes and comments from Social Engagement monitoring when enabled in the workspace, or a user-provided/exported engager list. Ask whether Social Engagement is enabled before steering the user to a monitored-profile play. Profile-view capture is not treated as MCP-native.
- Founder voice capture is mandatory: collect 2-3 sample posts/messages or tone rules before founder-led outbound.

## Available recipes in this pack
#### Start here — no HubSpot needed
| Recipe | What it does | Needs |
|---|---|---|
| Social engagement flow — founder posts | Start with the warmest founder motion: ICP-qualify people engaging with your posts, or a relevant competitor founder/influencer profile if your own engagement is thin, then draft a light founder-voice touch for approval. No HubSpot required. | No HubSpot required; Social Engagement must be enabled in the workspace for monitored profiles, or use an exported engager list; profile views unavailable |
| Founder-led AI SDR — daily approval queue | Use a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 20/day Sales Nav/Premium founder-voice touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional |
| Social campaigns — founder-led narrow audience push | Build a one-time founder-led campaign such as leadership connections for feature feedback, VP Sales coffee invites during a travel week, or a focused product-update push, using approved static templates and flow-level approval. | No HubSpot required for Discover Contacts or connection/list sources; HubSpot required only for CRM-history segments |
#### Needs HubSpot, RB2B, or a FirstTouch-accessible source
| Recipe | What it does | Needs |
|---|---|---|
| Fast personal inbound follow-up | Connect with high-intent signups and demo requests on LinkedIn same day, in your voice. | HubSpot or FirstTouch-accessible inbound list/import required |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active, when HubSpot tracking or an RB2B/list source exists. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion |
| Scoop-up slipped leads | Use HubSpot lifecycle/deal/list data to find personal lost deals and dormant contacts worth a second look. This is a secondary CRM motion, not the no-HubSpot founder start. | HubSpot required |
| Stalled deal reactivation — 60-day open-deal workflow | Find contacts associated to open HubSpot deals that are not Closed Won/Lost and have had no engagement for 60+ days, then build an owner-approved LinkedIn reactivation queue. This is a secondary HubSpot motion after the no-HubSpot founder starts. | HubSpot required; RevOps/admin may be needed only for recurring workflow setup |

## Included skills and dependency status
| Skill | Needs |
|---|---|
| `firsttouch-messaging` | No HubSpot required |
| `inbound-speed-to-lead` | HubSpot or FirstTouch-accessible inbound list/import required; true automation needs a connected source |
| `warm-engager-followup` | No HubSpot required; Social Engagement must be enabled in the workspace for monitored profiles; user-provided/exported engager lists also work |
| `website-visitor-followup` | HubSpot tracking or RB2B/list source required |
| `founder-led-outbound` | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional |
| `social-campaigns` | No HubSpot for pure ICP/imported/connection-list campaigns; HubSpot required for CRM/deal/customer segments |
| `stalled-deal-reactivation` | HubSpot required; may need RevOps/admin for workflow setup |
| `hubspot-signal-to-linkedin-touch` | HubSpot required |

## HubSpot access rules for this pack
- If HubSpot is connected, HubSpot-specific recipes can read CRM context, owner, lifecycle/deal/list data, and log back where supported.
- If HubSpot is used but no MCP/key is connected, ask for a HubSpot list or other FirstTouch-accessible source before running HubSpot-dependent motions.
- If HubSpot is not used, run only the recipes above whose Needs column says no HubSpot or imported/Discover/list source is enough.

## Social Engagement source options
Social Engagement can monitor relevant LinkedIn profiles for post likes and comments. Prefer the user's own founder/leadership/company profile when available; if they do not have enough owned engagement yet, monitor a relevant competitor founder, category influencer, or executive profile and work the ICP-fit people engaging there. Profile views are not an available signal.

## Approval model
Publishing a flow activates it but does **not** enroll awaiting contacts. After approval, explicitly enroll the approved contacts/items, then confirm they moved from awaiting to in-progress.

| Motion | Approval style |
|---|---|
| AI SDR / dynamic actions | Row-level approval. Each first-touch row must be approved individually. |
| Warm engager, inbound, website visitor, HubSpot signal, customer/stalled deal | Row-level approval unless FirstTouch records an equivalent per-contact approval. |
| Social campaigns | Two modes: rep/BDR dynamic rows use row-level approval like AI SDR; RevOps/founder one-time static campaigns can use flow-level approval after exact audience, templates, sender/routing rule, launch window, and daily cap are approved. |

## Onboarding output format
```markdown
## FirstTouch onboarding summary
- Persona: founder
- LinkedIn account: Free/basic or Sales Navigator/Premium
- Daily connection cap: 10 or 20 shared across all plays
- HubSpot access: MCP / service key / list only / none
- ICP/list available if no HubSpot: yes/no + source
- Plays available now from this pack: ...
- Plays blocked until HubSpot access/list or source data exists: ...
- Recommended first play: ...
- Approval workflow: row-level for dynamic plays; flow-level only for approved one-time social campaigns
```
