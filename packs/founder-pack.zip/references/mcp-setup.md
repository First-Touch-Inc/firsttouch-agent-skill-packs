# MCP Setup — Connecting the Tools Your Plays Need

Each play lists the MCPs it requires. Connect them once; they're shared across all plays.

---

## 1. FirstTouch MCP (required by every play)

FirstTouch is the execution layer — it's what lets the agent actually perform LinkedIn actions and log them.

**Connect in Claude / Cursor / your harness:**
- **Server URL:** `https://mcp.firsttouch.ai`
- **Auth:** OAuth (browser flow) or API key from your FirstTouch workspace settings
- **Scope:** scoped to the authorized user's LinkedIn account and connected HubSpot

**Verify it's connected:**
> Ask the agent: *"List my active FirstTouch campaigns and the seats connected."*

If the agent can return campaign + seat data, the MCP is live.

**What it exposes (conceptual tool surface):**
- Campaign control — launch, pause, edit
- LinkedIn actions — connection request, message, InMail, profile view
- Engagement data — who liked/commented/viewed, inbox replies
- Logging — write LinkedIn activity to HubSpot timelines
- Safety — seat usage, daily limits, duplicate checks

---

## 2. HubSpot MCP (required by plays 02, 03, 04, 05, 07, 10)

HubSpot is the system of record — it gives the agent the CRM context that makes outreach *smart* and *owner-safe*.

**Connect:**
- **Server URL:** `https://mcp.hubspot.com/anthropic` (Anthropic-hosted) — or your HubSpot MCP endpoint
- **Auth:** OAuth (connect from your HubSpot account; grant the scopes the plays need)
- **Scopes typically needed:** contacts (read), companies (read), deals (read), owners (read), lists (read), timeline activity (read). Write scopes only if a play explicitly logs back.

**Verify:**
> *"Show me 5 contacts in lifecycle stage 'Marketing Qualified Lead' and their owner."*

**What it exposes:**
- Contacts & companies — properties, lifecycle, owner, activity
- Deals — stage, amount, last activity, close date
- Lists — active/static membership
- Owners — the humans who own relationships (for routing)

---

## 3. Enrichment MCP (optional — plays 03, 10)

For finding LinkedIn URLs, emails, and firmographics when HubSpot is missing them.

**Options:**
- **Clay MCP** — richest for ICP + waterfall enrichment
- **Surfe MCP** — LinkedIn-native enrichment + CRM sync
- **Any provider MCP** your team already uses

Connect per the provider's docs. Not required for the pack to function, but it materially improves champion-mapping and founder-outbound plays.

---

## Connection checklist (do this before running any play)

- [ ] FirstTouch MCP connected and returns campaign data
- [ ] HubSpot MCP connected and returns contacts + owners (if your play needs it)
- [ ] The authorized FirstTouch user's LinkedIn account is healthy (not near limits)
- [ ] You know **who owns** the target contacts in HubSpot (plays route by owner)
- [ ] You've decided the **approval workflow** — Slack, email, or in-agent review (see `safety-governance.md`)

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Agent says it "can't send" | FirstTouch MCP not connected or OAuth expired | Re-auth in workspace settings |
| Agent ignores owner routing | HubSpot MCP missing or no owner scope | Reconnect HubSpot MCP with owner read scope |
| Agent drafts but never logs | Logging not enabled / wrong HubSpot portal | Confirm FirstTouch↔HubSpot sync is active |
| Duplicate messages sent | Duplicate-check skipped | Ensure the play runs the "already contacted?" gate (see `safety-governance.md`) |
