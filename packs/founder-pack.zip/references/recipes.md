# Recipe Catalog — Founder Pack

Use this file when the agent installed `skills/` and `references/` without loading the root README. These recipes are the recommended starting points for the founder persona.

## Recommended start point
Start with **Social engagement flow — founder posts**. If the founder does not have enough post engagement yet, monitor a relevant competitor founder, category influencer, or executive profile and work the people engaging there. Use **Founder-led AI SDR** only after the warm-engagement path or when the user explicitly wants a cold ICP queue. Use **Social campaigns** for narrow founder-led pushes such as feature feedback, product-update feedback, or travel-week outreach.

## Recipes
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social engagement flow — founder posts | Start with the warmest founder motion: ICP-qualify people engaging with your posts, or a relevant competitor founder/influencer profile if your own engagement is thin, then draft a light founder-voice touch for approval. No HubSpot required. | No HubSpot required; paid, non-trial Social Engagement required for monitored profiles, or use an exported engager list; profile views unavailable | `warm-engager-followup` + `firsttouch-messaging` |
| Founder-led AI SDR — daily approval queue | Use a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 20/day Sales Nav/Premium founder-voice touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `founder-led-outbound` |
| Social campaigns — founder-led narrow audience push | Build a one-time founder-led campaign such as leadership connections for feature feedback, VP Sales coffee invites during a travel week, or a focused product-update push, using approved static templates and flow-level approval. | No HubSpot required for Discover Contacts or connection/list sources; HubSpot required only for CRM-history segments | `social-campaigns` + `firsttouch-messaging` |
| Fast personal inbound follow-up | Connect with high-intent signups and demo requests on LinkedIn same day, in your voice. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active, when HubSpot tracking or an RB2B/list source exists. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion | `website-visitor-followup` + `firsttouch-messaging` |
| Scoop-up slipped leads | Use HubSpot lifecycle/deal/list data to find personal lost deals and dormant contacts worth a second look. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Stalled deal reactivation — 60-day open-deal workflow | Find contacts associated to open deals that are not Closed Won/Lost and have had no engagement for 60+ days, then build an owner-approved LinkedIn reactivation queue. Optional RevOps/admin workflow setup can automate the list later. | HubSpot required; RevOps/admin may be needed only for recurring workflow setup | `stalled-deal-reactivation` + `firsttouch-messaging` |

## Approval reminder
Dynamic/AI SDR rows require row-level approval. Static social-campaign flows can use flow-level approval only after the exact audience, static templates, sender/routing rule, launch window, and daily cap are approved.
