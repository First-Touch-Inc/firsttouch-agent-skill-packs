# Recipe Catalog — Founder Pack

Use this file when the agent installed `skills/` and `references/` without loading the root README. These recipes are the recommended starting points for the founder persona.

## Recommended start point
1. **Check Social Engagement first:** run **Social engagement flow: founder posts** from owned founder or executive personal profiles. If Social Engagement is not enabled, turn it on through FirstTouch MCP for the monitored profile. If owned personal-profile engagement is thin, monitor a relevant competitor founder or category influencer personal profile. FirstTouch does not track company-page/profile engagement.
2. **No engager source right now:** if no monitored profile or engager list is available, run **Founder-led AI SDR** from ICP + FirstTouch Discover Contacts.
3. **Have HubSpot:** add inbound, visitor, and stalled-deal plays as secondary CRM/deal motions, not the default path.

## Recipes
#### Start here — no HubSpot needed
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Social engagement flow — founder posts | Social Engagement can be enabled through FirstTouch MCP; Start with the warmest founder motion: ICP-qualify people engaging with your posts, or a relevant competitor founder/influencer profile if your own engagement is thin, then draft a light founder-voice touch for approval. No HubSpot required. | No HubSpot required; Social Engagement can be enabled through FirstTouch MCP for monitored profiles; profile views unavailable | `warm-engager-followup` + `firsttouch-messaging` |
| Founder-led AI SDR — daily approval queue | Use a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to the recommended recommended 10/day free/basic or 20/day Sales Nav/Premium founder-voice touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional | `founder-led-outbound` |
| Social campaigns — founder-led narrow audience push | Build a one-time founder-led campaign such as leadership connections for feature feedback, VP Sales coffee invites during a travel week, or a focused product-update push, using approved static templates and flow-level approval. | No HubSpot required for Discover Contacts or connection/list sources; HubSpot required only for CRM-history segments | `social-campaigns` + `firsttouch-messaging` |
#### Needs HubSpot, RB2B, or a FirstTouch-accessible source
| Play | What it does | Needs | Composes from |
|---|---|---|---|
| Fast personal inbound follow-up | Connect with high-intent signups and demo requests on LinkedIn same day, in your voice. | HubSpot or FirstTouch-accessible inbound list/import required | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active, when HubSpot tracking or an RB2B/list source exists. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion | `website-visitor-followup` + `firsttouch-messaging` |
| Scoop-up slipped leads | Use HubSpot lifecycle/deal/list data to find personal lost deals and dormant contacts worth a second look. This is a secondary CRM motion, not the no-HubSpot founder start. | HubSpot required | `hubspot-signal-to-linkedin-touch` + `firsttouch-messaging` |
| Stalled deal reactivation — 60-day open-deal workflow | Find contacts associated to open HubSpot deals that are not Closed Won/Lost and have had no engagement for 60+ days, then build an owner-approved LinkedIn reactivation queue. This is a secondary HubSpot motion after the no-HubSpot founder starts. | HubSpot required; RevOps/admin may be needed only for recurring workflow setup | `stalled-deal-reactivation` + `firsttouch-messaging` |

## Approval reminder
Dynamic/AI SDR rows require row-level approval. Static social-campaign flows can use flow-level approval only after the exact audience, static templates, sender/routing rule, launch window, and daily cap are approved.
