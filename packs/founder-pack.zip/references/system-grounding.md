# System Grounding — How FirstTouch, HubSpot, and Agents Fit Together

*Read this once. This reference is shared across packs; execute only the skills and recipes included in the installed pack.*

---

## The three layers

```
┌─────────────────────────────────────────────────────────┐
│  REASONING LAYER                                        │
│  Claude / ChatGPT / Cursor / Codex — the AI agent       │
│  Reads signals, decides who + what + when, drafts copy  │
└───────────────┬─────────────────────────────────────────┘
                │ calls tools via MCP
┌───────────────▼─────────────────────────────────────────┐
│  EXECUTION LAYER                                        │
│  FirstTouch — "the hands"                               │
│  Performs LinkedIn actions, respects safety limits,     │
│  routes by owner, logs every touch                      │
└───────────────┬─────────────────────────────────────────┘
                │ logs + attributes to
┌───────────────▼─────────────────────────────────────────┐
│  SYSTEM OF RECORD                                       │
│  HubSpot — the brain / CRM                              │
│  Contacts, companies, deals, lifecycle, owners,         │
│  activity timelines, pipeline                           │
└─────────────────────────────────────────────────────────┘
```

**The key idea:** the AI agent is the brain and FirstTouch is the governed execution layer. FirstTouch can run standalone through Audiences, Flow Plans, Discover Contacts, Dynamic Actions, and Social Engagement. HubSpot adds CRM memory: owner routing, lifecycle/deal signals, and timeline logging when connected. An agent without FirstTouch can *think* about outreach but can't *perform* it safely or log it.

---

## What FirstTouch actually does (the execution layer)

FirstTouch is the **HubSpot-native LinkedIn outreach and social selling platform**. Through its MCP, an agent can:

- **Trigger** supported LinkedIn/social actions (connection requests, messages, flow steps, manual tasks) from HubSpot workflows or directly
- **Track** every touch and **attribute** it to contacts, companies, and deals
- **Log** LinkedIn activity to HubSpot where the FirstTouch-HubSpot integration and workspace permissions support it
- **Respect** routing rules (owner-based), approval gates, and account-safety limits
- **Expose** a public MCP server (`mcp.firsttouch.ai`) so AI agents run outreach without a browser

Customer-facing positioning reference: works with HubSpot-connected workflows where configured and is built around **human-in-the-loop** execution. Check the live pricing and compliance pages before quoting price, HubSpot edition coverage, or certification details.

---

## What HubSpot provides (the system of record)

When the **HubSpot MCP** is connected, the agent can read:

- **Contacts & companies** — properties, lifecycle stage, owner, recent activity
- **Deals** — stage, amount, last activity date, probability
- **Lists** — static and active (e.g. "engaged but no meeting," "staged > 14 days")
- **Timeline activity** — emails, meetings, notes, and (via FirstTouch) LinkedIn touches
- **Owners** — who owns the relationship (critical for routing)

This is what makes plays **attribution-aware** and **owner-safe**. Without HubSpot context, an agent would blindly message prospects regardless of relationship state.

---

## The loop every play follows

Most plays implement a version of this cycle:

```
1. SIGNAL      ← a HubSpot event, a LinkedIn engagement, or a time condition
2. QUALIFY     ← is this the right person, right account, right moment?
3. DRAFT       ← personalize the touch (see messaging-framework.md)
4. GATE        ← human approval before any send (see safety-governance.md)
5. EXECUTE     ← FirstTouch performs the LinkedIn action
6. LOG         ← FirstTouch logs to HubSpot timeline
7. MEASURE     ← track replies, meetings, influenced pipeline
```

Steps 1–4 and 6–7 are where the agent earns its keep. Step 5 is FirstTouch. **Step 4 (the gate) is non-negotiable** — it's what makes this safe for real accounts.

---

## Which MCPs each play needs

| MCP | What it gives the agent | Required by |
|-----|------------------------|-------------|
| **FirstTouch MCP** | LinkedIn action execution, engagement data, logging | Every play |
| **HubSpot MCP** | CRM context, lifecycle, owners, deals, lists | Required for HubSpot signal touches, stalled deal reactivation, customer/customer-milestone plays when installed, and CRM/deal/customer segments. Optional but useful for inbound speed-to-lead, website visitor follow-up, AI SDR, warm engagement, and social campaigns when those can start from FirstTouch/imported/Discover sources. |
| **FirstTouch enrichment + optional external enrichment MCP** | LinkedIn URLs, emails, firmographics | FirstTouch can enrich when credits/data are available; Clay/Surfe/etc. are optional supplements, not prerequisites |

Full setup instructions: [`mcp-setup.md`](mcp-setup.md).

## Social Engagement source note

LinkedIn Social Engagement monitoring is a FirstTouch feature for post likes and comments. Prefer the user's own founder, executive, or company profile when there is enough owned engagement. If owned engagement is thin, monitor a relevant competitor founder, category influencer, or executive profile and work the ICP-fit people engaging there. Do not use profile views as a signal.

## FirstTouch object glossary

This pack uses human-friendly terms because users ask for "campaigns," "sequences," and "queues." When executing, translate them into the object the connected FirstTouch MCP supports:

| Pack term | FirstTouch execution concept |
|---|---|
| Play | The overall workflow the agent follows |
| Audience/list | The contacts/accounts selected for a motion |
| Flow plan/campaign/sequence | The approved series of LinkedIn actions and timing |
| Dynamic action queue | Per-contact actions awaiting row-level approval |
| Enrollment | Adding approved contacts to the flow/campaign |

The agent should state the exact FirstTouch object used so the user does not have to guess where approval or execution happened.

---

## Agent persona: the "competent team member"

The agent should behave like a **competent, cautious SDR**, not a script:

- It **checks context before acting** (never messages a contact already in an active sequence)
- It **drafts for review** by default (never sends without the gate)
- It **logs what it did** so the human can audit
- It **knows when to stop** and ask, rather than push volume

This persona is reinforced in every play's `SKILL.md`. If an agent ever seems to be racing to send volume, something is wrong — pull it back to draft-and-gate.
