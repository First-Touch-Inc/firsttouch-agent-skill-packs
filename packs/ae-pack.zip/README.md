# FirstTouch AE Pack

> Deals dying in silence while champions go dark and pipeline looks fine until it doesn't — these are the plays for the job you actually do.

## Who this is for
You carry a number. Your whole job depends on deals staying alive and champions staying warm. Most CRM data tells you what happened last month — these plays tell you what to do today about the deal that's going quiet. You need fast inbound follow-up, multi-threading on booked meetings, and reactivation plays for pipeline that's been silent too long.

## Your plays

### ✅ Ready now (skills)
| Play | What it does | Runs |
|---|---|---|
| firsttouch-messaging | Write on-brand, high-converting LinkedIn outreach messages — connection requests, openers, follow-ups, and meeting asks — calibrated to the prospect's seniority and a real signal. | `firsttouch-messaging` |
| owner-safe-outreach-operator | Ensure every LinkedIn outreach action respects owner routing, duplicate checks, account-safety limits, and human approval before it sends — then logs to HubSpot. | `owner-safe-outreach-operator` |
| inbound-speed-to-lead | Attach LinkedIn connection requests and lightweight follow-up to inbound signups, trial starts, demo requests, or other high-intent HubSpot events. | `inbound-speed-to-lead` |
| warm-engager-followup | Turn people who recently liked, commented on, or viewed your LinkedIn posts or profile into conversations and pipeline. | `warm-engager-followup` |
| website-visitor-followup | Turn website-visitor intent into LinkedIn outreach by using de-anonymized visitor data or HubSpot website-visitor signals, checking connection status, drafting a lightweight message, and gating execution for approval. | `website-visitor-followup` |
| icp-outbound-builder | Build an ICP outbound motion from a HubSpot list or a FirstTouch target-account set: qualify accounts, identify the right personas, enrich/match contacts, and add them into an approved FirstTouch flow. | `icp-outbound-builder` |
| hubspot-signal-to-linkedin-touch | Turn a HubSpot CRM event — lifecycle stage change, deal stage movement, form fill, list addition — into a timely, personalized LinkedIn touch. | `hubspot-signal-to-linkedin-touch` |
| champion-mapper | Map the likely internal champions and decision-makers across a target account by combining HubSpot company/contact data with LinkedIn relationships and enrichment. | `champion-mapper` |
| stalled-deal-reactivation | Restart stuck or stalled HubSpot deals using timely, low-pressure LinkedIn touches backed by social proof and fresh context. | `stalled-deal-reactivation` |

### ⚠️ Recipes (composable, run with guidance)
| Play | What it does | Composes from |
|---|---|---|
| Auto-connect on meeting or signup | Agent connects with prospects the moment they book or submit, before the moment cools | `inbound-speed-to-lead` + `firsttouch-messaging` |
| Social engager flow — leadership's audience | Reach people engaging with company content before they go cold | `warm-engager-followup` + `icp-outbound-builder` |
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active | `website-visitor-followup` + `icp-outbound-builder` |
| AE AI SDR — connect and intro | Outbound LinkedIn sequences: connect first, build context, no meeting ask early | `icp-outbound-builder` + `owner-safe-outreach-operator` + `firsttouch-messaging` |
| Scoop-up slipped leads — stale opps | Identify and re-engage dormant deals and pipeline that has gone quiet 30+ days | `hubspot-signal-to-linkedin-touch` + `stalled-deal-reactivation` + `firsttouch-messaging` |
| Meeting-booked multi-thread | When a meeting books, auto-connect other decision-makers so you're not single-threaded | `hubspot-signal-to-linkedin-touch` + `champion-mapper` + `firsttouch-messaging` |
| Closed-lost reengagement | Re-engage closed-lost deals with no engagement for 60+ days via a fresh LinkedIn touch | `hubspot-signal-to-linkedin-touch` + `icp-outbound-builder` + `firsttouch-messaging` |

### 🔜 Roadmap (not yet shipped)
- Rep-led AI SDR — see `roadmap/rep-led-ai-sdr.md`

## Install
1. Download this pack (or clone the repo).
2. Drop the `skills/` folder into your agent:
   - **Claude Code:** copy each skill folder to `~/.claude/skills/<skill-name>/` (or `.claude/skills/` per-project)
   - **Claude.ai:** Settings → Features → Skills → upload the pack `.zip`. *(If claude.ai only registers the first skill, unzip locally and upload each `<skill>/` folder's zip individually.)*
   - **Cursor / Windsurf:** copy the `skills/` folder anywhere the agent reads
   - **ChatGPT:** MCP connector only — no skills folder. Connect `https://mcp.firsttouch.ai` via Settings → Connectors.
3. Connect MCPs: **FirstTouch MCP** + **HubSpot MCP** for most plays. See `references/mcp-setup.md`.

## Safety
- No play sends on its own. Every outbound action passes an approval gate.
- Built around LinkedIn's real limits. Owner/territory-safe routing.
- See `references/safety-governance.md`.

## What's NOT included
- **Rep-led AI SDR** — see `roadmap/rep-led-ai-sdr.md`
