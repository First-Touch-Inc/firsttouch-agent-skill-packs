# First-Run Onboarding — AE Pack

This onboarding is scoped to the skills and recipes actually included in this installed pack.

## Ask before running anything
1. **LinkedIn account type:** free/basic or Sales Navigator/Premium.
   - Free/basic: no connection notes; 10 connection requests/day max.
   - Sales Navigator/Premium: connection notes available for approved warm signals; up to 20 connection requests/day.
   - AI SDR and all other connection-request plays share the same daily budget.
   - If AI SDR and a social campaign run on the same sender/day, pause/reduce one motion or split the daily cap explicitly before queueing sends.
   - Already-connected first-message rows use a separate, non-FirstTouch-enforced norm of 20/day on free/basic LinkedIn and up to 40/day on Sales Navigator/Premium. Stay well under it and reduce volume if acceptance or reply quality drops.
2. **HubSpot access:** MCP connected by an admin, service key/private app token from an admin, HubSpot list only, or none. Do not ask a rep/BDR to mint credentials they do not own.
3. **ICP/list/source data:** if HubSpot is absent, ask for ICP criteria or an imported/FirstTouch-accessible list before qualifying prospects.
4. **Persona start point:** recommend the persona-specific start point below, not a generic catalog dump.

## Persona start point
1. **Meeting booked / signup source:** run **Auto-connect on meeting or signup** first. This is the AE #1 use case: same-day LinkedIn auto-connect/follow-up from booked meetings, signups, or a manually exported meeting-booked list.
2. **HubSpot + stakeholder expansion:** run **Meeting-booked stakeholder follow-up** when a booked-meeting source/list is available and the AE wants to multi-thread the account.
3. **No HubSpot/list access:** run **AE AI SDR** from ICP + Discover Contacts; this cannot touch existing pipeline without HubSpot or a FirstTouch-accessible contact list.
4. **HubSpot + quiet pipeline:** run **Stalled deal reactivation** from a manually filtered contact list.
5. **HubSpot MCP + tasks already created for LinkedIn/social steps:** run **Automate due HubSpot social tasks** as a secondary task runner for tasks due today, not as a cadence/list creator.

- Social engagement / warm engager flows are delivered by `warm-engager-followup`. They use LinkedIn post likes and comments from Social Engagement monitoring when enabled in the workspace, or a user-provided/exported engager list. Ask whether Social Engagement is enabled before steering the user to a monitored-profile play. Profile-view capture is not treated as MCP-native.

## Available recipes in this pack
#### HubSpot-connected deal and inbound plays
| Recipe | What it does | Needs |
|---|---|---|
| Auto-connect on meeting or signup | Draft a same-day LinkedIn touch for approval when prospects book or submit. An AE can run this once today from a HubSpot/exported inbound contact list; recurring automation needs a connected source or RevOps workflow. | HubSpot or FirstTouch-accessible inbound list/import required; AE can run once from a manual list; RevOps needed only for recurring automation |
| Social campaigns — territory and deal expansion | Build a narrow AE push for a territory, event, customer expansion, or stalled-pipeline segment. Default to row-level dynamic approvals like AI SDR; use static flow-level approval only when RevOps/founder approves the exact audience and templates. | No HubSpot required for pure ICP/imported/Discover segments; HubSpot required for territory/deal/customer CRM segments; row-level approval by default |
| Stalled deal reactivation — 60-day open-deal workflow | Find contacts associated to open deals that are not Closed Won/Lost and have had no engagement for 60+ days, then build an owner-approved LinkedIn reactivation queue. Treat recurring workflow setup as a RevOps/admin step unless already configured. | HubSpot required; an AE with HubSpot access can run once from a manually built/filtered contact list; RevOps/admin needed only for recurring workflow setup |
| Meeting-booked stakeholder follow-up | Draft stakeholder LinkedIn touches from a meeting-booked contact list/source so the deal is not single-threaded. An AE can run this once today from a manually filtered HubSpot list; RevOps is needed only for recurring setup. | HubSpot required; AE can run once from a manually built meeting-booked contact list/source; RevOps needed only for recurring workflow setup |
| Closed-lost reengagement | Re-engage historical closed-lost accounts from a HubSpot Closed Lost contact list with a fresh, approved LinkedIn touch and a separate win-back angle; keep this separate from stalled open-deal reactivation. | HubSpot required; run from a Closed Lost contact list; separate from stalled open-deal workflow |
#### CRM social task automation: only if tasks already exist
| Recipe | What it does | Needs |
|---|---|---|
| Automate due HubSpot social tasks | Find HubSpot tasks due today in the AE/user queue that already represent LinkedIn connect/message/social follow-up steps, execute eligible ones through FirstTouch, and mark the CRM tasks complete after queue/send confirmation. | HubSpot MCP required; use only if HubSpot tasks for social steps are already being created each day; not a cadence/list creator or prospecting engine |
#### No-HubSpot / self-serve starts
| Recipe | What it does | Needs |
|---|---|---|
| Social engager flow — leadership's audience | Reach people engaging with leadership/executive personal-profile content before they go cold. | No HubSpot required; use leadership/executive personal-profile, competitor founder, or influencer personal-profile engagement; HubSpot optional for qualification/routing; profile views unavailable |
| AE AI SDR — daily approval queue | View a HubSpot contact/company list or discover a new ICP list, enrich each prospect, and draft up to 10/day free or 20/day Sales Nav/Premium AE-owned LinkedIn touches for approval. | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional |
#### Intent source required: HubSpot tracking, RB2B, or list/import
| Recipe | What it does | Needs |
|---|---|---|
| Website visitor play | Turn pricing/demo/product-page visits into LinkedIn touches while intent is active; if no visitor signal source exists, choose the AE AI SDR recipe as a separate prospecting motion instead. | HubSpot tracking or RB2B/list source required; if no visitor signal source exists, use the persona AI SDR recipe as a separate prospecting motion |

## Included skills and dependency status
| Skill | Needs |
|---|---|
| `firsttouch-messaging` | No HubSpot required |
| `inbound-speed-to-lead` | HubSpot or FirstTouch-accessible inbound list/import required; true automation needs a connected source |
| `warm-engager-followup` | No HubSpot required; Social Engagement must be enabled in the workspace for monitored profiles; user-provided/exported engager lists also work |
| `website-visitor-followup` | HubSpot tracking or RB2B/list source required |
| `icp-outbound-builder` | No HubSpot required with ICP brief + FirstTouch Discover Contacts; HubSpot list optional |
| `hubspot-signal-to-linkedin-touch` | HubSpot required |
| `hubspot-social-task-runner` | HubSpot MCP required; use only when LinkedIn/social tasks already exist daily |
| `social-campaigns` | No HubSpot for pure ICP/imported/connection-list campaigns; HubSpot required for CRM/deal/customer segments |
| `stalled-deal-reactivation` | HubSpot required; may need RevOps/admin for workflow setup |

## HubSpot access rules for this pack
- If HubSpot is connected, HubSpot-specific recipes can read CRM context, owner, lifecycle/deal/list data, and log back where the connected FirstTouch-HubSpot integration supports it.
- If HubSpot is used but no MCP/key is connected, ask for a HubSpot list or other FirstTouch-accessible source before running HubSpot-dependent motions.
- If HubSpot is not used, run only the recipes above whose Needs column says no HubSpot or imported/Discover/list source is enough.

## Social Engagement source options
Social Engagement can monitor relevant LinkedIn profiles for post likes and comments. Prefer the user's own founder/leadership personal profile when available; if they do not have enough owned engagement yet, monitor a relevant competitor founder, category influencer, or executive profile and work the ICP-fit people engaging there. Profile views are not an available signal.

## Approval model
Publishing a flow activates it but does **not** enroll awaiting contacts. After approval, explicitly enroll the approved contacts/items, then confirm they moved from awaiting to in-progress.

| Motion | Approval style |
|---|---|
| AI SDR / dynamic actions | Row-level approval. Each first-touch row must be approved individually. |
| Warm engager, inbound, website visitor, HubSpot signal, customer/stalled deal | Row-level approval unless FirstTouch records an equivalent per-contact approval. |
| Social campaigns | Two modes: rep/BDR dynamic rows use row-level approval like AI SDR; RevOps/founder one-time static campaigns can use flow-level approval after exact audience, templates, sender/routing rule, launch window, and daily cap are approved. |

## Onboarding output format
```markdown
## FirstTouch onboarding summary
- Persona: ae
- LinkedIn account: Free/basic or Sales Navigator/Premium
- Daily connection cap: 10 or 20 shared across all plays
- Daily message norm: 20/day free/basic or up to 40/day Sales Nav/Premium for already-connected first-message rows, FirstTouch-supported; stay well under it
- HubSpot access: MCP / service key / list only / none
- Social Engagement enabled: yes/no/unknown
- ICP/list available if no HubSpot: yes/no + source
- Plays available now from this pack: ...
- Plays blocked until HubSpot access/list or source data exists: ...
- Recommended first play: ...
- Approval workflow: row-level for dynamic plays; flow-level only for approved one-time social campaigns
```
